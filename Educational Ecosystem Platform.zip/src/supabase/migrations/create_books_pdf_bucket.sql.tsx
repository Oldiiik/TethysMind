-- ============================================
-- SUPABASE STORAGE: BOOKS PDF BUCKET
-- ============================================
-- Этот скрипт создает бакет для хранения PDF файлов книг
-- и настраивает политики доступа (RLS)

-- 1. Создаем бакет для PDF книг
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'books-pdf',
  'books-pdf',
  true, -- Публичный доступ для чтения
  52428800, -- 50 MB лимит на файл (50 * 1024 * 1024)
  ARRAY['application/pdf']::text[] -- Только PDF файлы
)
ON CONFLICT (id) DO NOTHING;

-- 2. Политика: Пользователи могут загружать PDF только в свою папку
CREATE POLICY "Users can upload PDFs to their own folder"
ON storage.objects
FOR INSERT
TO authenticated, anon
WITH CHECK (
  bucket_id = 'books-pdf' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 3. Политика: Пользователи могут читать свои PDF файлы
CREATE POLICY "Users can read their own PDFs"
ON storage.objects
FOR SELECT
TO authenticated, anon
USING (
  bucket_id = 'books-pdf' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 4. Политика: Пользователи могут обновлять свои PDF файлы
CREATE POLICY "Users can update their own PDFs"
ON storage.objects
FOR UPDATE
TO authenticated, anon
USING (
  bucket_id = 'books-pdf' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 5. Политика: Пользователи могут удалять свои PDF файлы
CREATE POLICY "Users can delete their own PDFs"
ON storage.objects
FOR DELETE
TO authenticated, anon
USING (
  bucket_id = 'books-pdf' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- ============================================
-- ПРИМЕЧАНИЯ:
-- ============================================
-- Структура хранения: userId/bookId/book.pdf
-- Пример пути: "550e8400-e29b-41d4-a716-446655440000/123/book.pdf"
-- 
-- Лимиты:
-- - Максимальный размер файла: 50 MB
-- - Только PDF файлы (application/pdf)
-- - Публичный доступ на чтение (для всех пользователей)
-- 
-- Безопасность:
-- - Каждый пользователь может загружать/читать/обновлять/удалять только свои файлы
-- - Файлы хранятся в папках по userId для изоляции
-- ============================================
