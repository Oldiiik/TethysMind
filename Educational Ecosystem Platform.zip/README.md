
  # Educational Ecosystem Platform

  This is a code bundle for Educational Ecosystem Platform. The original project is available at https://www.figma.com/design/D7dPTJ1TFVoKOyyPJ6NdjC/Educational-Ecosystem-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  