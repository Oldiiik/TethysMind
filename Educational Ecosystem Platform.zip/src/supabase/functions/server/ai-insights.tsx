import { createClient } from 'jsr:@supabase/supabase-js@2';

export async function generateInsights(c: any) {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));

    if (!bookId) {
      return c.json({ error: 'Book ID is required' }, 400);
    }

    console.log('🔍 Generating AI insights for book:', bookId, 'user:', userId);

    // Create Supabase client with SERVICE_ROLE_KEY
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get GEMINI_API_KEY from env table
    const { data: envData, error: envError } = await supabase
      .from('env')
      .select('VITE_GEMINI_API_KEY')
      .single();

    if (envError || !envData?.VITE_GEMINI_API_KEY) {
      console.error('⚠️ GEMINI_API_KEY not found in env table:', envError);
      return c.json({ 
        error: 'GEMINI_API_KEY not configured',
        instructions: 'Please add VITE_GEMINI_API_KEY to env table'
      }, 500);
    }

    const GEMINI_API_KEY = envData.VITE_GEMINI_API_KEY;

    // Get all notes for this book
    const { data: notes, error: notesError } = await supabase
      .from('notes')
      .select('*')
      .eq('book_id', bookId)
      .eq('user_id', userId)
      .order('created_at', { ascending: true });

    if (notesError) {
      console.error('❌ Error fetching notes:', notesError);
      return c.json({ error: 'Failed to fetch notes' }, 500);
    }

    if (!notes || notes.length === 0) {
      return c.json({ message: 'No notes found for this book', insights: [], count: 0 }, 200);
    }

    console.log(`📝 Found ${notes.length} notes`);

    // Prepare notes for AI
    const notesText = notes.map((note: any, index: number) => 
      `Note ${index + 1} (Page ${note.page}):\nHighlighted: ${note.selected_text}\nNote: ${note.note_text}`
    ).join('\n\n');

    console.log('🤖 Calling Gemini API...');

    // Call Gemini AI
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            role: 'user',
            parts: [{
              text: `You are an intelligent study assistant analyzing a student's reading notes.

Based on the following notes from a book, generate 3-5 key insights that:
1. Synthesize main themes and concepts
2. Identify patterns across notes
3. Suggest connections between ideas
4. Highlight important takeaways
5. Formulate thought-provoking questions

Notes:
${notesText}

Generate insights in JSON format:
[
  {
    "text": "Insight text here in Russian",
    "type": "key_concept" | "summary" | "question" | "connection",
    "relevance": 0.0-1.0
  }
]

IMPORTANT: 
- Write all insights in RUSSIAN language
- Provide ONLY the JSON array, no additional text
- No markdown formatting`
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
          }
        })
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('❌ Gemini API error:', geminiResponse.status, errorText);
      return c.json({ 
        error: 'Gemini API error', 
        details: errorText,
        status: geminiResponse.status,
        url: 'gemini-2.5-flash API'
      }, 500);
    }

    const geminiData = await geminiResponse.json();
    const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!responseText) {
      console.error('❌ No response from Gemini');
      return c.json({ error: 'No response from Gemini API' }, 500);
    }
    
    console.log('📊 AI Response received:', responseText.substring(0, 200));

    // Parse AI response
    let insights: any[] = [];
    try {
      const cleanedText = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      insights = JSON.parse(cleanedText);
    } catch (parseError) {
      console.error('❌ Failed to parse AI response:', parseError);
      console.error('Response was:', responseText);
      return c.json({ error: 'Failed to parse AI response' }, 500);
    }

    console.log(`✨ Generated ${insights.length} insights`);

    // Delete old insights for this book/user
    await supabase
      .from('ai_insights')
      .delete()
      .eq('book_id', bookId)
      .eq('user_id', userId);

    // Save new insights to database
    const insightsToSave = insights.map((insight: any) => ({
      book_id: bookId,
      user_id: userId,
      insight_text: insight.text,
      insight_type: insight.type || 'general',
      relevance_score: insight.relevance || 0.8,
      source_notes: notes.map((n: any) => n.id)
    }));

    const { data: savedInsights, error: saveError } = await supabase
      .from('ai_insights')
      .insert(insightsToSave)
      .select();

    if (saveError) {
      console.error('❌ Error saving insights:', saveError);
      return c.json({ error: 'Failed to save insights' }, 500);
    }

    console.log('💾 Insights saved successfully');

    return c.json({ 
      success: true, 
      insights: savedInsights,
      count: savedInsights.length
    });

  } catch (error) {
    console.error('❌ Error generating insights:', error);
    return c.json({ 
      error: 'Failed to generate insights',
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
}

export async function getInsights(c: any) {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));

    if (!bookId) {
      return c.json({ error: 'Book ID is required' }, 400);
    }

    console.log('📖 Getting insights for book:', bookId, 'user:', userId);

    // Create Supabase client with SERVICE_ROLE_KEY
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get insights
    const { data: insights, error } = await supabase
      .from('ai_insights')
      .select('*')
      .eq('book_id', bookId)
      .eq('user_id', userId)
      .order('relevance_score', { ascending: false });

    if (error) {
      console.error('❌ Error fetching insights:', error);
      return c.json({ error: 'Failed to fetch insights' }, 500);
    }

    console.log(`📊 Found ${insights?.length || 0} insights`);

    return c.json({ insights: insights || [] });

  } catch (error) {
    console.error('❌ Error getting insights:', error);
    return c.json({ 
      error: 'Failed to get insights',
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
}