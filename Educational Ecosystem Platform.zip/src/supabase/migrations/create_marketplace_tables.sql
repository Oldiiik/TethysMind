-- ============================================
-- TETHYSMIND MARKETPLACE DATABASE SCHEMA
-- ============================================
-- This script creates all necessary tables for the marketplace functionality
-- Including: items, purchases, reviews, and creator stats

-- ============================================
-- 1. MARKETPLACE ITEMS TABLE
-- ============================================
-- Stores all marketplace content (courses, books, materials)

CREATE TABLE IF NOT EXISTS marketplace_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Basic Information
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  content TEXT, -- Long form content/syllabus
  
  -- Author Information
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  
  -- Type and Category
  type TEXT NOT NULL CHECK (type IN ('course', 'book', 'material')),
  category TEXT NOT NULL, -- technologyAndIT, businessAndEconomics, etc.
  
  -- Pricing
  price DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (price >= 0),
  commission_rate DECIMAL(3, 2) NOT NULL DEFAULT 0.20, -- Platform commission (0.20 = 20%)
  
  -- Media
  thumbnail_url TEXT,
  content_file_url TEXT, -- URL to PDF/ZIP in Supabase Storage
  
  -- Features
  what_you_learn TEXT[], -- Array of learning outcomes
  requirements TEXT[], -- Array of prerequisites
  
  -- Status and Flags
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  is_premium BOOLEAN NOT NULL DEFAULT false,
  
  -- Stats
  sales_count INTEGER NOT NULL DEFAULT 0,
  rating DECIMAL(3, 2) NOT NULL DEFAULT 0.00 CHECK (rating >= 0 AND rating <= 5),
  review_count INTEGER NOT NULL DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  published_at TIMESTAMP WITH TIME ZONE
);

-- Indexes for marketplace_items
CREATE INDEX IF NOT EXISTS idx_marketplace_items_author ON marketplace_items(author_id);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_type ON marketplace_items(type);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_category ON marketplace_items(category);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_status ON marketplace_items(status);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_price ON marketplace_items(price);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_rating ON marketplace_items(rating DESC);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_sales ON marketplace_items(sales_count DESC);
CREATE INDEX IF NOT EXISTS idx_marketplace_items_created ON marketplace_items(created_at DESC);

-- Full-text search index
CREATE INDEX IF NOT EXISTS idx_marketplace_items_search 
ON marketplace_items USING GIN (to_tsvector('english', title || ' ' || description || ' ' || author_name));

-- ============================================
-- 2. MARKETPLACE PURCHASES TABLE
-- ============================================
-- Tracks all purchases and enrollments

CREATE TABLE IF NOT EXISTS marketplace_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Purchase Information
  item_id UUID NOT NULL REFERENCES marketplace_items(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Financial
  price_paid DECIMAL(10, 2) NOT NULL,
  platform_commission DECIMAL(10, 2) NOT NULL,
  creator_earnings DECIMAL(10, 2) NOT NULL,
  
  -- Payment Information
  payment_method TEXT, -- 'stripe', 'paypal', 'free', etc.
  payment_id TEXT, -- External payment ID from Stripe/PayPal
  payment_status TEXT NOT NULL DEFAULT 'completed' CHECK (payment_status IN ('pending', 'completed', 'refunded', 'failed')),
  
  -- Access
  access_granted BOOLEAN NOT NULL DEFAULT true,
  access_expires_at TIMESTAMP WITH TIME ZONE, -- NULL for lifetime access
  
  -- Timestamps
  purchased_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  refunded_at TIMESTAMP WITH TIME ZONE
);

-- Indexes for marketplace_purchases
CREATE INDEX IF NOT EXISTS idx_purchases_item ON marketplace_purchases(item_id);
CREATE INDEX IF NOT EXISTS idx_purchases_user ON marketplace_purchases(user_id);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON marketplace_purchases(purchased_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_purchases_unique ON marketplace_purchases(item_id, user_id) 
WHERE payment_status = 'completed';

-- ============================================
-- 3. MARKETPLACE REVIEWS TABLE
-- ============================================
-- User reviews and ratings for marketplace items

CREATE TABLE IF NOT EXISTS marketplace_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Review Information
  item_id UUID NOT NULL REFERENCES marketplace_items(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Review Content
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT NOT NULL,
  comment TEXT NOT NULL,
  
  -- Flags
  is_verified_purchase BOOLEAN NOT NULL DEFAULT false,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Unique constraint: one review per user per item
  UNIQUE(item_id, user_id)
);

-- Indexes for marketplace_reviews
CREATE INDEX IF NOT EXISTS idx_reviews_item ON marketplace_reviews(item_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON marketplace_reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON marketplace_reviews(rating DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_created ON marketplace_reviews(created_at DESC);

-- ============================================
-- 4. CREATOR STATISTICS TABLE
-- ============================================
-- Aggregated statistics for content creators

CREATE TABLE IF NOT EXISTS creator_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  
  -- Sales Statistics
  total_sales INTEGER NOT NULL DEFAULT 0,
  total_revenue DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  total_earnings DECIMAL(12, 2) NOT NULL DEFAULT 0.00, -- After commission
  platform_commission_paid DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  
  -- Monthly Statistics
  monthly_sales INTEGER NOT NULL DEFAULT 0,
  monthly_revenue DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  monthly_earnings DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  
  -- Content Statistics
  total_content INTEGER NOT NULL DEFAULT 0,
  published_content INTEGER NOT NULL DEFAULT 0,
  draft_content INTEGER NOT NULL DEFAULT 0,
  
  -- Rating Statistics
  average_rating DECIMAL(3, 2) NOT NULL DEFAULT 0.00,
  total_reviews INTEGER NOT NULL DEFAULT 0,
  
  -- Timestamps
  month_year TEXT NOT NULL, -- Format: YYYY-MM
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for creator_stats
CREATE INDEX IF NOT EXISTS idx_creator_stats_creator ON creator_stats(creator_id);
CREATE INDEX IF NOT EXISTS idx_creator_stats_month ON creator_stats(month_year DESC);

-- ============================================
-- 5. MARKETPLACE CATEGORIES TABLE
-- ============================================
-- Predefined categories for marketplace items

CREATE TABLE IF NOT EXISTS marketplace_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Category Information
  code TEXT NOT NULL UNIQUE, -- technologyAndIT, businessAndEconomics, etc.
  name_ru TEXT NOT NULL,
  name_kk TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_ru TEXT,
  description_kk TEXT,
  description_en TEXT,
  
  -- Display
  icon TEXT, -- Icon name from lucide-react
  color TEXT, -- Hex color code
  display_order INTEGER NOT NULL DEFAULT 0,
  
  -- Status
  is_active BOOLEAN NOT NULL DEFAULT true,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default categories
INSERT INTO marketplace_categories (code, name_ru, name_kk, name_en, icon, color, display_order) VALUES
  ('technologyAndIT', 'Технологии и IT', 'Технология және IT', 'Technology & IT', 'Code', '#3B82F6', 1),
  ('businessAndEconomics', 'Бизнес и экономика', 'Бизнес және экономика', 'Business & Economics', 'TrendingUp', '#10B981', 2),
  ('medicineAndHealth', 'Медицина и здравоохранение', 'Медицина және денсаулық', 'Medicine & Health', 'Heart', '#EF4444', 3),
  ('engineering', 'Инженерия', 'Инженерия', 'Engineering', 'Cpu', '#F59E0B', 4),
  ('artsAndDesign', 'Искусство и дизайн', 'Өнер және дизайн', 'Arts & Design', 'Palette', '#8B5CF6', 5),
  ('scienceAndResearch', 'Наука и исследования', 'Ғылым және зерттеу', 'Science & Research', 'Microscope', '#06B6D4', 6),
  ('languages', 'Языки', 'Тілдер', 'Languages', 'Languages', '#EC4899', 7),
  ('personalDevelopment', 'Личностное развитие', 'Жеке даму', 'Personal Development', 'User', '#14B8A6', 8)
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- 6. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE marketplace_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE creator_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_categories ENABLE ROW LEVEL SECURITY;

-- ============================================
-- MARKETPLACE ITEMS POLICIES
-- ============================================

-- Anyone can view published items
CREATE POLICY "Public can view published items"
ON marketplace_items FOR SELECT
USING (status = 'published');

-- Creators can view their own items (any status)
CREATE POLICY "Creators can view own items"
ON marketplace_items FOR SELECT
USING (auth.uid() = author_id);

-- Creators can create items
CREATE POLICY "Creators can create items"
ON marketplace_items FOR INSERT
WITH CHECK (auth.uid() = author_id);

-- Creators can update their own items
CREATE POLICY "Creators can update own items"
ON marketplace_items FOR UPDATE
USING (auth.uid() = author_id)
WITH CHECK (auth.uid() = author_id);

-- Creators can delete their own items
CREATE POLICY "Creators can delete own items"
ON marketplace_items FOR DELETE
USING (auth.uid() = author_id);

-- ============================================
-- MARKETPLACE PURCHASES POLICIES
-- ============================================

-- Users can view their own purchases
CREATE POLICY "Users can view own purchases"
ON marketplace_purchases FOR SELECT
USING (auth.uid() = user_id);

-- Users can create purchases (buying)
CREATE POLICY "Users can create purchases"
ON marketplace_purchases FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Creators can view purchases of their items
CREATE POLICY "Creators can view item purchases"
ON marketplace_purchases FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM marketplace_items
    WHERE marketplace_items.id = marketplace_purchases.item_id
    AND marketplace_items.author_id = auth.uid()
  )
);

-- ============================================
-- MARKETPLACE REVIEWS POLICIES
-- ============================================

-- Anyone can view reviews
CREATE POLICY "Public can view reviews"
ON marketplace_reviews FOR SELECT
TO public
USING (true);

-- Users can create reviews for items they purchased
CREATE POLICY "Users can create reviews"
ON marketplace_reviews FOR INSERT
WITH CHECK (
  auth.uid() = user_id
  AND EXISTS (
    SELECT 1 FROM marketplace_purchases
    WHERE marketplace_purchases.item_id = marketplace_reviews.item_id
    AND marketplace_purchases.user_id = auth.uid()
    AND marketplace_purchases.payment_status = 'completed'
  )
);

-- Users can update their own reviews
CREATE POLICY "Users can update own reviews"
ON marketplace_reviews FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Users can delete their own reviews
CREATE POLICY "Users can delete own reviews"
ON marketplace_reviews FOR DELETE
USING (auth.uid() = user_id);

-- ============================================
-- CREATOR STATS POLICIES
-- ============================================

-- Creators can view their own stats
CREATE POLICY "Creators can view own stats"
ON creator_stats FOR SELECT
USING (auth.uid() = creator_id);

-- ============================================
-- MARKETPLACE CATEGORIES POLICIES
-- ============================================

-- Anyone can view categories
CREATE POLICY "Public can view categories"
ON marketplace_categories FOR SELECT
TO public
USING (is_active = true);

-- ============================================
-- 7. FUNCTIONS AND TRIGGERS
-- ============================================

-- Function to update marketplace_items updated_at timestamp
CREATE OR REPLACE FUNCTION update_marketplace_items_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_marketplace_items_updated_at
BEFORE UPDATE ON marketplace_items
FOR EACH ROW
EXECUTE FUNCTION update_marketplace_items_updated_at();

-- Function to update item rating when review is added/updated/deleted
CREATE OR REPLACE FUNCTION update_item_rating()
RETURNS TRIGGER AS $$
BEGIN
  -- Recalculate average rating and review count
  UPDATE marketplace_items
  SET 
    rating = COALESCE((
      SELECT AVG(rating)::DECIMAL(3,2)
      FROM marketplace_reviews
      WHERE item_id = COALESCE(NEW.item_id, OLD.item_id)
    ), 0),
    review_count = (
      SELECT COUNT(*)
      FROM marketplace_reviews
      WHERE item_id = COALESCE(NEW.item_id, OLD.item_id)
    )
  WHERE id = COALESCE(NEW.item_id, OLD.item_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_item_rating_on_review
AFTER INSERT OR UPDATE OR DELETE ON marketplace_reviews
FOR EACH ROW
EXECUTE FUNCTION update_item_rating();

-- Function to update sales count and creator stats on purchase
CREATE OR REPLACE FUNCTION update_sales_stats()
RETURNS TRIGGER AS $$
DECLARE
  v_item marketplace_items%ROWTYPE;
  v_current_month TEXT;
BEGIN
  -- Only process completed purchases
  IF NEW.payment_status = 'completed' THEN
    -- Get item details
    SELECT * INTO v_item FROM marketplace_items WHERE id = NEW.item_id;
    
    -- Increment sales count
    UPDATE marketplace_items
    SET sales_count = sales_count + 1
    WHERE id = NEW.item_id;
    
    -- Get current month in YYYY-MM format
    v_current_month := TO_CHAR(NOW(), 'YYYY-MM');
    
    -- Update or create creator stats
    INSERT INTO creator_stats (
      creator_id,
      month_year,
      total_sales,
      total_revenue,
      total_earnings,
      platform_commission_paid,
      monthly_sales,
      monthly_revenue,
      monthly_earnings
    )
    VALUES (
      v_item.author_id,
      v_current_month,
      1,
      NEW.price_paid,
      NEW.creator_earnings,
      NEW.platform_commission,
      1,
      NEW.price_paid,
      NEW.creator_earnings
    )
    ON CONFLICT (creator_id, month_year) 
    DO UPDATE SET
      total_sales = creator_stats.total_sales + 1,
      total_revenue = creator_stats.total_revenue + NEW.price_paid,
      total_earnings = creator_stats.total_earnings + NEW.creator_earnings,
      platform_commission_paid = creator_stats.platform_commission_paid + NEW.platform_commission,
      monthly_sales = creator_stats.monthly_sales + 1,
      monthly_revenue = creator_stats.monthly_revenue + NEW.price_paid,
      monthly_earnings = creator_stats.monthly_earnings + NEW.creator_earnings,
      updated_at = NOW();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_sales_stats
AFTER INSERT ON marketplace_purchases
FOR EACH ROW
EXECUTE FUNCTION update_sales_stats();

-- Function to update creator_stats content counts
CREATE OR REPLACE FUNCTION update_creator_content_stats()
RETURNS TRIGGER AS $$
DECLARE
  v_current_month TEXT;
BEGIN
  v_current_month := TO_CHAR(NOW(), 'YYYY-MM');
  
  -- Recalculate content stats for the creator
  INSERT INTO creator_stats (
    creator_id,
    month_year,
    total_content,
    published_content,
    draft_content
  )
  SELECT 
    COALESCE(NEW.author_id, OLD.author_id),
    v_current_month,
    COUNT(*),
    COUNT(*) FILTER (WHERE status = 'published'),
    COUNT(*) FILTER (WHERE status = 'draft')
  FROM marketplace_items
  WHERE author_id = COALESCE(NEW.author_id, OLD.author_id)
  ON CONFLICT (creator_id, month_year)
  DO UPDATE SET
    total_content = EXCLUDED.total_content,
    published_content = EXCLUDED.published_content,
    draft_content = EXCLUDED.draft_content,
    updated_at = NOW();
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_creator_content_stats
AFTER INSERT OR UPDATE OR DELETE ON marketplace_items
FOR EACH ROW
EXECUTE FUNCTION update_creator_content_stats();

-- ============================================
-- 8. STORAGE BUCKET FOR MARKETPLACE
-- ============================================
-- Note: Run this in Supabase SQL Editor or via server code

-- Create storage bucket for marketplace content
-- This will be created via server code on first upload

-- ============================================
-- MIGRATION COMPLETE
-- ============================================

COMMENT ON TABLE marketplace_items IS 'Stores all marketplace content including courses, books, and materials';
COMMENT ON TABLE marketplace_purchases IS 'Tracks all purchases and enrollments with payment information';
COMMENT ON TABLE marketplace_reviews IS 'User reviews and ratings for marketplace items';
COMMENT ON TABLE creator_stats IS 'Aggregated statistics for content creators';
COMMENT ON TABLE marketplace_categories IS 'Predefined categories for marketplace organization';
