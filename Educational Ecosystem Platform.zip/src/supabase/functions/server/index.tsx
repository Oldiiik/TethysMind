import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2.39.3";

const app = new Hono();

// Enable logger
app.use('*', logger());

// Helper to convert snake_case to camelCase
function toCamelCase(obj: any): any {
  if (Array.isArray(obj)) {
    return obj.map(toCamelCase);
  } else if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((acc: any, key: string) => {
      const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
      acc[camelKey] = toCamelCase(obj[key]);
      return acc;
    }, {});
  }
  return obj;
}

// Helper to convert camelCase to snake_case
function toSnakeCase(obj: any): any {
  if (Array.isArray(obj)) {
    return obj.map(toSnakeCase);
  } else if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((acc: any, key: string) => {
      const snakeKey = key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
      acc[snakeKey] = toSnakeCase(obj[key]);
      return acc;
    }, {});
  }
  return obj;
}

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-User-Token"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Helper to get Supabase client
function getSupabaseClient(accessToken?: string) {
  // ALWAYS use SERVICE_ROLE_KEY on server for database operations
  // Our custom token is only for user identification, not for Supabase auth
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  
  // Debug logging
  if (!supabaseUrl || !serviceRoleKey) {
    console.error('❌ Missing Supabase credentials!');
    console.error('   SUPABASE_URL:', supabaseUrl ? 'set' : 'MISSING');
    console.error('   SUPABASE_SERVICE_ROLE_KEY:', serviceRoleKey ? 'set' : 'MISSING');
    console.error('');
    console.error('🔧 FIX: These are automatically provided by Supabase Edge Functions');
    console.error('   No manual configuration needed!');
  }
  
  return createClient(
    supabaseUrl ?? '',
    serviceRoleKey ?? ''
  );
}

// Middleware to verify token
async function verifyToken(c: any, next: any) {
  // Get token from custom header (not Authorization to avoid Supabase JWT validation)
  const token = c.req.header('X-User-Token');
  const path = c.req.path;
  
  console.log('🔐 Auth Middleware:', { 
    path, 
    hasToken: !!token, 
    tokenPreview: token ? token.substring(0, 20) + '...' : 'none' 
  });
  
  // Skip auth check for public endpoints
  if (
    path.includes('/auth/signup') || 
    path.includes('/auth/signin') || 
    path.includes('/health') ||
    path.includes('/test') ||
    path.includes('/leaderboard/global') ||
    path.includes('/ai/mentor/') ||
    // Marketplace public endpoints
    (path.includes('/marketplace/items') && !path.includes('/creator'))
  ) {
    console.log('✅ Public endpoint - skipping auth');
    await next();
    return;
  }
  
  if (!token) {
    console.error('❌ No token provided for protected endpoint:', path);
    return c.json({ error: "No token provided" }, 401);
  }
  
  // Parse token (userId:timestamp)
  const userId = token.split(':')[0];
  
  if (!userId) {
    console.error('❌ Invalid token format');
    return c.json({ error: "Invalid token" }, 401);
  }
  
  console.log('✅ Token verified for user:', userId);
  
  // Store userId in context for use in handlers
  c.set('userId', userId);
  
  await next();
}

// Apply auth middleware to all routes
app.use('/make-server-6738f032/*', verifyToken);

// Health check endpoint
app.get("/make-server-6738f032/health", (c) => {
  return c.json({ status: "ok" });
});

// ============= AUTH =============

// Register/Sign up
app.post("/make-server-6738f032/auth/signup", async (c) => {
  try {
    const { email, password, name, role = 'student' } = await c.req.json();
    
    const supabase = getSupabaseClient();
    
    // Проверяем есть ли уже такой email
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();
    
    if (existingUser) {
      return c.json({ error: 'Пользователь с таким email уже существует' }, 400);
    }
    
    // Создаем пользователя в таблице users
    const { data: newUser, error } = await supabase
      .from('users')
      .insert({
        email,
        name,
        role,
        password: password // Простой текст ля прототипа
      })
      .select()
      .single();
    
    if (error) {
      console.error("[Supabase] Signup error:", error);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ 
      success: true, 
      user: { 
        id: newUser.id, 
        email: newUser.email, 
        name: newUser.name, 
        role: newUser.role 
      } 
    });
  } catch (error) {
    console.error("[Supabase] Signup error:", error);
    return c.json({ error: "Failed to sign up" }, 500);
  }
});

// Sign in
app.post("/make-server-6738f032/auth/signin", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const supabase = getSupabaseClient();
    
    // Находим пользователя по email
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();
    
    if (error || !user) {
      console.error("Signin error: User not found");
      return c.json({ error: 'Неверный email или пароль' }, 401);
    }
    
    // Проверяем пароль (в production: await bcrypt.compare(password, user.password))
    if (user.password !== password) {
      return c.json({ error: 'Неверный email или пароль' }, 401);
    }
    
    // Убираем пароль из отвт
    const { password: _, ...userWithoutPassword } = user;
    
    return c.json({ 
      success: true, 
      user: userWithoutPassword,
      // Генерируем простой токен (в production нужен JWT)
      token: `${user.id}:${Date.now()}`
    });
  } catch (error) {
    console.error("Signin error:", error);
    return c.json({ error: "Failed to sign in" }, 500);
  }
});

// Get current user by token
app.get("/make-server-6738f032/auth/me", async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: "No token provided" }, 401);
    }
    
    // Парсим токен (userId:timestamp)
    const userId = token.split(':')[0];
    
    const supabase = getSupabaseClient();
    
    // Получаем пользователя из таблицы users
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }
    
    // Убираем пароль из ответа
    const { password: _, ...userWithoutPassword } = user;
    
    return c.json({ user: userWithoutPassword });
  } catch (error) {
    console.error("Auth me error:", error);
    return c.json({ error: "Failed to get user" }, 500);
  }
});

// Link student to parent
app.post("/make-server-6738f032/auth/link-student", async (c) => {
  try {
    const { parentId, studentEmail } = await c.req.json();
    
    const supabase = getSupabaseClient();
    
    // Find student by email
    const { data: student, error: findError } = await supabase
      .from('users')
      .select('*')
      .eq('email', studentEmail)
      .eq('role', 'student')
      .single();
    
    if (findError || !student) {
      return c.json({ error: "Student not found" }, 404);
    }
    
    // Update parent profile
    const { error: updateError } = await supabase
      .from('users')
      .update({ linked_student_id: student.id })
      .eq('id', parentId)
      .eq('role', 'parent');
    
    if (updateError) {
      return c.json({ error: "Failed to link student" }, 500);
    }
    
    return c.json({ success: true, student });
  } catch (error) {
    console.error("Link student error:", error);
    return c.json({ error: "Failed to link student" }, 500);
  }
});

// ============= USER PROFILE =============

// Get user profile
app.get("/make-server-6738f032/profile/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    const { data: profile, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 = not found
      console.error("Error getting profile:", error);
      return c.json({ error: "Failed to get profile" }, 500);
    }
    
    if (!profile) {
      return c.json({
        id: userId,
        name: "Новый пользователь",
        bio: "",
        direction: "technology",
        avatar: null,
        tethys_points: 0,
        rank: "cadet",
        books_read: 0,
      });
    }
    
    return c.json(profile);
  } catch (error) {
    console.error("Error getting profile:", error);
    return c.json({ error: "Failed to get profile" }, 500);
  }
});

// Update user profile
app.post("/make-server-6738f032/profile/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const data = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('users')
      .update(data)
      .eq('id', userId);
    
    if (error) {
      console.error("Error updating profile:", error);
      return c.json({ error: "Failed to update profile" }, 500);
    }
    
    return c.json({ success: true, data });
  } catch (error) {
    console.error("Error updating profile:", error);
    return c.json({ error: "Failed to update profile" }, 500);
  }
});

// ============= FRIENDS =============

// Get friends list
app.get("/make-server-6738f032/friends/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    const { data: friendships, error } = await supabase
      .from('friends')
      .select(`
        friend_id,
        added_at,
        friend:users!friends_friend_id_fkey(*)
      `)
      .eq('user_id', userId);
    
    if (error) {
      console.error("Error getting friends:", error);
      return c.json({ error: "Failed to get friends" }, 500);
    }
    
    const friends = friendships?.map((f: any) => ({
      ...f.friend,
      addedAt: f.added_at
    })) || [];
    
    return c.json(friends);
  } catch (error) {
    console.error("Error getting friends:", error);
    return c.json({ error: "Failed to get friends" }, 500);
  }
});

// Add friend
app.post("/make-server-6738f032/friends/:userId/add", async (c) => {
  try {
    const userId = c.req.param("userId");
    const friend = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('friends')
      .insert({
        user_id: userId,
        friend_id: friend.id
      });
    
    if (error) {
      console.error("Error adding friend:", error);
      return c.json({ error: "Failed to add friend" }, 500);
    }
    
    // Get updated friends list
    const { data: friendships } = await supabase
      .from('friends')
      .select(`
        friend_id,
        added_at,
        friend:users!friends_friend_id_fkey(*)
      `)
      .eq('user_id', userId);
    
    const friends = friendships?.map((f: any) => ({
      ...f.friend,
      addedAt: f.added_at
    })) || [];
    
    return c.json({ success: true, friends });
  } catch (error) {
    console.error("Error adding friend:", error);
    return c.json({ error: "Failed to add friend" }, 500);
  }
});

// Remove friend
app.delete("/make-server-6738f032/friends/:userId/:friendId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const friendId = c.req.param("friendId");
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('friends')
      .delete()
      .eq('user_id', userId)
      .eq('friend_id', friendId);
    
    if (error) {
      console.error("Error removing friend:", error);
      return c.json({ error: "Failed to remove friend" }, 500);
    }
    
    // Get updated friends list
    const { data: friendships } = await supabase
      .from('friends')
      .select(`
        friend_id,
        added_at,
        friend:users!friends_friend_id_fkey(*)
      `)
      .eq('user_id', userId);
    
    const friends = friendships?.map((f: any) => ({
      ...f.friend,
      addedAt: f.added_at
    })) || [];
    
    return c.json({ success: true, friends });
  } catch (error) {
    console.error("Error removing friend:", error);
    return c.json({ error: "Failed to remove friend" }, 500);
  }
});

// ============= LIBRARY =============

// Get all books for user
app.get("/make-server-6738f032/books/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    console.log('📚 Getting books for user:', userId);
    
    const { data: books, error } = await supabase
      .from('books')
      .select('*')
      .eq('user_id', userId)
      .order('date_added', { ascending: false });
    
    if (error) {
      console.error("Error getting books:", error);
      return c.json({ error: "Failed to get books" }, 500);
    }
    
    console.log('📚 Books found:', books?.length || 0);
    
    // Return object with books array (not just array)
    return c.json({ books: toCamelCase(books || []) });
  } catch (error) {
    console.error("Error getting books:", error);
    return c.json({ error: "Failed to get books" }, 500);
  }
});

// Upload PDF file
app.post("/make-server-6738f032/books/:userId/upload-pdf", async (c) => {
  try {
    const userId = c.req.param("userId");
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const bookId = formData.get('bookId') as string;
    
    if (!file || !bookId) {
      return c.json({ error: "File and bookId are required" }, 400);
    }
    
    const supabase = getSupabaseClient();
    
    // Create file path: userId/bookId/book.pdf
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${bookId}/book.${fileExt}`;
    
    // Convert File to ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // Upload to Supabase Storage
    const { data, error } = await supabase.storage
      .from('books-pdf')
      .upload(fileName, uint8Array, {
        contentType: file.type,
        cacheControl: '3600',
        upsert: true
      });
    
    if (error) {
      console.error("Error uploading PDF:", error);
      return c.json({ error: "Failed to upload PDF" }, 500);
    }
    
    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('books-pdf')
      .getPublicUrl(fileName);
    
    return c.json({ success: true, url: publicUrl });
  } catch (error) {
    console.error("Error uploading PDF:", error);
    return c.json({ error: "Failed to upload PDF" }, 500);
  }
});

// Delete PDF file
app.delete("/make-server-6738f032/books/:userId/:bookId/pdf", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = c.req.param("bookId");
    const supabase = getSupabaseClient();
    
    const fileName = `${userId}/${bookId}/book.pdf`;
    
    const { error } = await supabase.storage
      .from('books-pdf')
      .remove([fileName]);
    
    if (error) {
      console.error("Error deleting PDF:", error);
      return c.json({ error: "Failed to delete PDF" }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting PDF:", error);
    return c.json({ error: "Failed to delete PDF" }, 500);
  }
});

// Add book
app.post("/make-server-6738f032/books/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const book = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { data: newBook, error } = await supabase
      .from('books')
      .insert({
        user_id: userId,
        ...book
      })
      .select()
      .single();
    
    if (error) {
      console.error("Error adding book:", error);
      return c.json({ error: "Failed to add book" }, 500);
    }
    
    return c.json({ success: true, book: newBook });
  } catch (error) {
    console.error("Error adding book:", error);
    return c.json({ error: "Failed to add book" }, 500);
  }
});

// Update book
app.put("/make-server-6738f032/books/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const updates = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { data: updatedBook, error } = await supabase
      .from('books')
      .update(updates)
      .eq('id', bookId)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error("Error updating book:", error);
      return c.json({ error: "Failed to update book" }, 500);
    }
    
    if (!updatedBook) {
      return c.json({ error: "Book not found" }, 404);
    }
    
    return c.json({ success: true, book: updatedBook });
  } catch (error) {
    console.error("Error updating book:", error);
    return c.json({ error: "Failed to update book" }, 500);
  }
});

// Delete book
app.delete("/make-server-6738f032/books/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('books')
      .delete()
      .eq('id', bookId)
      .eq('user_id', userId);
    
    if (error) {
      console.error("Error deleting book:", error);
      return c.json({ error: "Failed to delete book" }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting book:", error);
    return c.json({ error: "Failed to delete book" }, 500);
  }
});

// ============= PORTFOLIO =============

// Get portfolio
app.get("/make-server-6738f032/portfolio/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    const { data: portfolio, error } = await supabase
      .from('portfolio')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error("Error getting portfolio:", error);
      return c.json({ error: "Failed to get portfolio" }, 500);
    }
    
    if (!portfolio) {
      return c.json({
        subjects: [],
        ielts_score: "",
        sat_score: "",
        diplomas: [],
        total_points: 0,
      });
    }
    
    return c.json(portfolio);
  } catch (error) {
    console.error("Error getting portfolio:", error);
    return c.json({ error: "Failed to get portfolio" }, 500);
  }
});

// Update portfolio
app.post("/make-server-6738f032/portfolio/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const data = await c.req.json();
    const supabase = getSupabaseClient();
    
    // Upsert portfolio
    const { error: portfolioError } = await supabase
      .from('portfolio')
      .upsert({
        user_id: userId,
        ...data
      });
    
    if (portfolioError) {
      console.error("Error updating portfolio:", portfolioError);
      return c.json({ error: "Failed to update portfolio" }, 500);
    }
    
    // Update user total points
    const { error: userError } = await supabase
      .from('users')
      .update({ tethys_points: data.total_points || 0 })
      .eq('id', userId);
    
    if (userError) {
      console.error("Error updating user points:", userError);
    }
    
    return c.json({ success: true, data });
  } catch (error) {
    console.error("Error updating portfolio:", error);
    return c.json({ error: "Failed to update portfolio" }, 500);
  }
});

// ============= LEADERBOARD =============

// Get global leaderboard
app.get("/make-server-6738f032/leaderboard/global", async (c) => {
  try {
    const supabase = getSupabaseClient();
    
    const { data: users, error } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'student')
      .order('tethys_points', { ascending: false })
      .limit(100);
    
    if (error) {
      console.error("Error getting leaderboard:", error);
      return c.json({ error: "Failed to get leaderboard" }, 500);
    }
    
    const leaderboard = users?.map((u: any, index: number) => ({
      rank: index + 1,
      name: u.name || "Пользователь",
      points: u.tethys_points || 0,
      country: u.country || "Не указано",
      rankTitle: u.rank || "cadet",
      avatar: u.avatar,
    })) || [];
    
    return c.json(leaderboard);
  } catch (error) {
    console.error("Error getting leaderboard:", error);
    return c.json({ error: "Failed to get leaderboard" }, 500);
  }
});

// Get friends leaderboard
app.get("/make-server-6738f032/leaderboard/friends/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    // Get current user
    const { data: currentUser } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    // Get friends
    const { data: friendships } = await supabase
      .from('friends')
      .select(`
        friend:users!friends_friend_id_fkey(*)
      `)
      .eq('user_id', userId);
    
    const friends = friendships?.map((f: any) => f.friend) || [];
    
    const allUsers = [
      { ...currentUser, name: currentUser?.name || "Ты" },
      ...friends
    ];
    
    const sorted = allUsers
      .filter((u: any) => u && u.tethys_points !== undefined)
      .sort((a: any, b: any) => (b.tethys_points || 0) - (a.tethys_points || 0))
      .map((u: any, index: number) => ({
        rank: index + 1,
        name: u.name || "Пользователь",
        points: u.tethys_points || 0,
        country: u.country || "Не указано",
        rankTitle: u.rank || "cadet",
        avatar: u.avatar,
      }));
    
    return c.json(sorted);
  } catch (error) {
    console.error("Error getting friends leaderboard:", error);
    return c.json({ error: "Failed to get friends leaderboard" }, 500);
  }
});

// ============= SEARCH =============

// Search users for friend suggestions
app.get("/make-server-6738f032/search/users", async (c) => {
  try {
    const query = c.req.query("q") || "";
    const supabase = getSupabaseClient();
    
    const { data: users, error } = await supabase
      .from('users')
      .select('*')
      .eq('role', 'student')
      .ilike('name', `%${query}%`)
      .limit(20);
    
    if (error) {
      console.error("Error searching users:", error);
      return c.json({ error: "Failed to search users" }, 500);
    }
    
    const filtered = users?.map((u: any) => ({
      id: u.id,
      name: u.name,
      bio: u.bio || "",
      direction: u.direction || "technology",
      avatar: u.avatar,
      tethys_points: u.tethys_points || 0,
      rank: u.rank || "cadet",
      books_read: u.books_read || 0,
    })) || [];
    
    return c.json(filtered);
  } catch (error) {
    console.error("Error searching users:", error);
    return c.json({ error: "Failed to search users" }, 500);
  }
});

// ============= SKILLS MAP =============

// Get skills progress for a user
app.get("/make-server-6738f032/skills/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    const { data: skills, error } = await supabase
      .from('skills')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error("Error getting skills:", error);
      return c.json({ error: "Failed to get skills" }, 500);
    }
    
    // Convert array to object with direction as key
    const skillsObj = skills?.reduce((acc: any, skill: any) => {
      acc[skill.direction] = skill.skills_data;
      return acc;
    }, {}) || {};
    
    return c.json(skillsObj);
  } catch (error) {
    console.error("Error getting skills:", error);
    return c.json({ error: "Failed to get skills" }, 500);
  }
});

// Update skills progress
app.post("/make-server-6738f032/skills/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const data = await c.req.json();
    const supabase = getSupabaseClient();
    
    // Upsert skills for each direction
    for (const [direction, skillsData] of Object.entries(data)) {
      const { error } = await supabase
        .from('skills')
        .upsert({
          user_id: userId,
          direction,
          skills_data: skillsData
        }, {
          onConflict: 'user_id,direction'
        });
      
      if (error) {
        console.error(`Error updating skills for ${direction}:`, error);
      }
    }
    
    return c.json({ success: true, data });
  } catch (error) {
    console.error("Error updating skills:", error);
    return c.json({ error: "Failed to update skills" }, 500);
  }
});

// ============= ENV VARIABLES =============

// Get environment variable (for API keys, etc.)
app.get("/make-server-6738f032/env/:key", async (c) => {
  try {
    const key = c.req.param("key");
    const supabase = getSupabaseClient();
    
    const { data, error } = await supabase
      .from('env_variables')
      .select('value')
      .eq('key', key)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error("Error getting env:", error);
      return c.json({ error: "Failed to get env" }, 500);
    }
    
    return c.json({ value: data?.value || null });
  } catch (error) {
    console.error("Error getting env:", error);
    return c.json({ error: "Failed to get env" }, 500);
  }
});

// Set environment variable
app.post("/make-server-6738f032/env/:key", async (c) => {
  try {
    const key = c.req.param("key");
    const { value } = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('env_variables')
      .upsert({ key, value });
    
    if (error) {
      console.error("Error setting env:", error);
      return c.json({ error: "Failed to set env" }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error setting env:", error);
    return c.json({ error: "Failed to set env" }, 500);
  }
});

// ============= BOOK NOTES =============

// Get notes for a book
app.get("/make-server-6738f032/notes/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const supabase = getSupabaseClient();
    
    console.log('📝 Getting notes for book:', { userId, bookId });
    
    const { data: notes, error } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', userId)
      .eq('book_id', bookId)
      .order('created_at', { ascending: true });
    
    if (error) {
      console.error("❌ Error getting notes:", error);
      return c.json({ error: "Failed to get notes" }, 500);
    }
    
    console.log('📝 Notes found:', notes?.length || 0);
    
    // Don't convert here - frontend will handle conversion
    return c.json(notes || []);
  } catch (error) {
    console.error("Error getting notes:", error);
    return c.json({ error: "Failed to get notes" }, 500);
  }
});

// Add note to a book
app.post("/make-server-6738f032/notes/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const note = await c.req.json();
    const supabase = getSupabaseClient();
    
    console.log('📝 Adding note:', { userId, bookId, note });
    
    // Support both camelCase and snake_case field names
    const selectedText = note.selectedText || note.selected_text;
    const noteText = note.noteText || note.note_text;
    const page = note.page;
    const position = note.position || { x: 0, y: 0 };
    const color = note.color || '#FFD700';
    
    // Validate required fields
    if (!selectedText || !noteText) {
      console.error('❌ Missing required fields:', { 
        hasSelectedText: !!selectedText,
        hasNoteText: !!noteText,
        receivedData: note
      });
      return c.json({ 
        error: "selectedText and noteText are required",
        received: note 
      }, 400);
    }
    
    const { data: newNote, error } = await supabase
      .from('notes')
      .insert({
        user_id: userId,
        book_id: bookId,
        page: page,
        selected_text: selectedText,
        note_text: noteText,
        position: position,
        color: color
      })
      .select()
      .single();
    
    if (error) {
      console.error("❌ [Supabase] ❌ Error adding note:", error);
      return c.json({ error: "Failed to add note", details: error }, 500);
    }
    
    console.log('✅ Note added successfully');
    
    return c.json({ success: true, note: newNote });
  } catch (error) {
    console.error("Error adding note:", error);
    return c.json({ error: "Failed to add note" }, 500);
  }
});

// Delete note
app.delete("/make-server-6738f032/notes/:userId/:bookId/:noteId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const noteId = parseInt(c.req.param("noteId"));
    const supabase = getSupabaseClient();
    
    console.log('📝 Deleting note:', { userId, bookId, noteId });
    
    const { error } = await supabase
      .from('notes')
      .delete()
      .eq('id', noteId)
      .eq('user_id', userId)
      .eq('book_id', bookId);
    
    if (error) {
      console.error("❌ Error deleting note:", error);
      return c.json({ error: "Failed to delete note" }, 500);
    }
    
    console.log('✅ Note deleted successfully');
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting note:", error);
    return c.json({ error: "Failed to delete note" }, 500);
  }
});

// ============= AI ANALYSIS =============

// Get AI analysis for a book
app.get("/make-server-6738f032/ai/analysis/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const supabase = getSupabaseClient();
    
    const { data: analysis, error } = await supabase
      .from('book_analysis')
      .select('*')
      .eq('user_id', userId)
      .eq('book_id', bookId)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error("Error getting analysis:", error);
      return c.json({ error: "Failed to get analysis" }, 500);
    }
    
    return c.json(analysis || null);
  } catch (error) {
    console.error("Error getting analysis:", error);
    return c.json({ error: "Failed to get analysis" }, 500);
  }
});

// Save AI analysis
app.post("/make-server-6738f032/ai/analysis/:userId/:bookId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const bookId = parseInt(c.req.param("bookId"));
    const analysis = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('book_analysis')
      .upsert({
        user_id: userId,
        book_id: bookId,
        ...analysis
      });
    
    if (error) {
      console.error("Error saving analysis:", error);
      return c.json({ error: "Failed to save analysis" }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error saving analysis:", error);
    return c.json({ error: "Failed to save analysis" }, 500);
  }
});

// ============= AI TEXT GENERATION (GEMINI) =============

app.post("/make-server-6738f032/ai/gemini", async (c) => {
  try {
    const { prompt, model = 'gemini-2.5-flash' } = await c.req.json();
    
    if (!prompt) {
      return c.json({ error: "Prompt is required" }, 400);
    }
    
    // Получаем API ключ из переменных окружения
    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    
    // Если нет API ключа - возвращаем ошибку
    if (!GEMINI_API_KEY || GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
      console.error('⚠️ GEMINI_API_KEY not configured');
      console.error('📝 Please add GEMINI_API_KEY to Supabase Edge Functions secrets');
      console.error('🔗 Instructions: https://aistudio.google.com/app/apikey');
      return c.json({ 
        error: 'GEMINI_API_KEY not configured. Please add it to Supabase Edge Functions secrets.',
        instructions: 'Visit https://aistudio.google.com/app/apikey to get your API key'
      }, 500);
    }
    
    console.log('🤖 Generating text with Gemini API...', { model, promptLength: prompt.length });
    
    // Вызываем Gemini API
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                { text: prompt }
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('❌ Gemini API error:', geminiResponse.status, errorText);
      
      // Более понятные сообщения об ошибках
      if (geminiResponse.status === 401) {
        console.error('🔑 Invalid API key - check your GEMINI_API_KEY');
        return c.json({ 
          error: 'Invalid Gemini API key',
          details: 'Please check your GEMINI_API_KEY in Supabase secrets'
        }, 401);
      } else if (geminiResponse.status === 403) {
        console.error('🚫 API access forbidden - enable Gemini API in Google Cloud Console');
        return c.json({ 
          error: 'Gemini API access forbidden',
          details: 'Please enable Gemini API in your Google Cloud Console'
        }, 403);
      }
      
      throw new Error(`Gemini API error: ${geminiResponse.status} - ${errorText}`);
    }

    const geminiData = await geminiResponse.json();
    const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!responseText) {
      console.error('❌ No response text from Gemini API');
      console.error('📄 Full response:', JSON.stringify(geminiData));
      throw new Error('No response from Gemini API');
    }

    console.log('✅ Text generated successfully:', responseText.substring(0, 100) + '...');

    return c.json({ text: responseText });
    
  } catch (error) {
    console.error('❌ Gemini text generation error:', error);
    
    return c.json({
      error: error instanceof Error ? error.message : 'Failed to generate text'
    }, 500);
  }
});

// ============= USER SETTINGS =============

// Get user settings (theme, etc.)
app.get("/make-server-6738f032/settings/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const supabase = getSupabaseClient();
    
    const { data: settings, error } = await supabase
      .from('settings')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error("Error getting settings:", error);
      return c.json({ error: "Failed to get settings" }, 500);
    }
    
    return c.json(settings || { theme: 'light', language: 'ru' });
  } catch (error) {
    console.error("Error getting settings:", error);
    return c.json({ error: "Failed to get settings" }, 500);
  }
});

// Update user settings
app.post("/make-server-6738f032/settings/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const data = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('settings')
      .upsert({
        user_id: userId,
        ...data
      });
    
    if (error) {
      console.error("Error updating settings:", error);
      return c.json({ error: "Failed to update settings" }, 500);
    }
    
    return c.json({ success: true, data });
  } catch (error) {
    console.error("Error updating settings:", error);
    return c.json({ error: "Failed to update settings" }, 500);
  }
});

// ============= AI CERTIFICATE VERIFICATION =============

app.post("/make-server-6738f032/ai/verify-certificate", async (c) => {
  try {
    const { imageBase64, certificateName, description, level } = await c.req.json();
    
    // Получаем API ключ из переменных окружения
    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    
    // Если нет API ключа - возвращаем mock данные
    if (!GEMINI_API_KEY || GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
      console.log('⚠️ GEMINI_API_KEY not configured, using mock verification');
      
      // Mock режим для демонстрации
      const mockResult = {
        status: 'verified',
        confidence: 75,
        fields: {
          name: 'Иванов Иван',
          issuer: certificateName.includes('IMO') ? 'International Mathematical Olympiad' : 'Республиканский центр олимпиад',
          issueDate: '2024-07-15',
          certNumber: `CERT-${Date.now()}`,
          detectedLinks: []
        },
        legitimacyCheck: {
          isLegitimate: true,
          reason: '⚠️ Mock режим: Для реальной проверки настройте GEMINI_API_KEY в Supabase Dashboard → Project Settings → Edge Functions → Add secret',
          detectedOrganizations: [certificateName],
          sources: []
        }
      };
      
      return c.json(mockResult);
    }
    
    // Очищаем base64 от префикс
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    
    const levelText = level === 'republic' ? 'республиканкого' : 'международного';
    
    const prompt = `Ты — строгий эксперт по проверке академических сертификатов и дипломов.

ЗАДАЧА: Проана��изируй изображение сертификата ${levelText} уровня и определи его ПОДЛИННОСТЬ.

ЗАЯВЛЕННАЯ ИНФОРМАЦИЯ:
- Название: "${certificateName}"
- Описание: "${description}"
- Уровень: ${levelText}

ЧТО НУЖНО ПРОВЕРИТЬ:
1. Качество и профессионализм оформления
2. Наличие официальных логотипов/печатей организаций
3. Читаемость и грамотность текста
4. Соответствие заявленному уровню (${levelText})
5. Признаки подделки (плохое качество, опечатки, странный дизайн)

ИЗВЛЕКИ ИЗ ИЗОБРАЖЕНИЯ:
- Имя владельца сертификата
- Организацию, выдавшую сертификат
- Дату выдачи
- Номер сертификата
- QR-коды или ссылки для проверки
- Название соревнования/олимпиады

КРИТЕРИИ ОЦЕНКИ:
✅ ПОДТВЕРЖДЁН (verified) - если:
   - Профессиональный дизайн
   - Есть логотипы известных организаций
   - Чёткий текст без ошибок
   - Соответствует заявленному уровню
   - Есть номер/QR код для проверки

⚠️ НЕОПРЕДЕЛЁННО (uncertain) - если:
   - Качество среднее
   - Нет явных признаков подделки, но и не выглядит очень профессионально
   - Мало информации для проверки

❌ ОТКЛОНЁН (rejected) - если:
   - Плохое качество изображения
   - Явные опечатки или ошибки
   - Самодельный вид
   - Не соответствует заявленному уровню (напр. школьный сертификат для международного)
   - Отсутствуют официальные атрибуты

ФОРМАТ ОТВЕТА (строго JSON):
{
  "status": "verified|uncertain|rejected",
  "confidence": <число от 0 до 100>,
  "fields": {
    "name": "<имя владельца или null>",
    "issuer": "<организация или null>",
    "issueDate": "<дата или null>",
    "certNumber": "<номер или null>",
    "detectedLinks": ["<ссылка1>", "<ссылка2>"]
  },
  "legitimacyCheck": {
    "isLegitimate": <true/false>,
    "reason": "<подробное объяснение на русском>",
    "detectedOrganizations": ["<организация1>", "<организация2>"]
  }
}

ВАЖНО: Будь СТРОГИМ. Лучше отклонить сомнительный сертификат, чем пропустить подделку.
Верни ТОЛЬКО JSON, без дополнительного текста!`;

    console.log('🤖 Sending image to Gemini Vision API...');
    
    // Вызываем Gemini Vision API
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                { text: prompt },
                {
                  inline_data: {
                    mime_type: 'image/png',
                    data: cleanBase64,
                  },
                },
              ],
            },
          ],
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('❌ Gemini API error:', errorText);
      throw new Error(`Gemini API error: ${geminiResponse.status}`);
    }

    const geminiData = await geminiResponse.json();
    const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!responseText) {
      throw new Error('No response from Gemini API');
    }

    console.log('📝 Gemini Vision Response:', responseText);

    // Парсим JSON из ответа
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to parse JSON from Gemini response');
    }

    const parsed = JSON.parse(jsonMatch[0]);

    // Дополнительная проверка через Wikipedia если есть организация
    let sources: string[] = [];
    if (parsed.fields?.issuer) {
      try {
        const wikiResponse = await fetch(
          `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(parsed.fields.issuer)}&limit=1&format=json`
        );
        const wikiData = await wikiResponse.json();
        if (wikiData[3]?.[0]) {
          sources.push(wikiData[3][0]);
        }
      } catch (error) {
        console.log('Wikipedia check failed:', error);
      }
    }

    const finalAnalysis = {
      status: parsed.status || 'uncertain',
      confidence: parsed.confidence || 50,
      fields: {
        name: parsed.fields?.name || null,
        issuer: parsed.fields?.issuer || null,
        issueDate: parsed.fields?.issueDate || null,
        certNumber: parsed.fields?.certNumber || null,
        detectedLinks: parsed.fields?.detectedLinks || []
      },
      legitimacyCheck: {
        isLegitimate: parsed.legitimacyCheck?.isLegitimate || false,
        reason: parsed.legitimacyCheck?.reason || 'Анализ завершён',
        detectedOrganizations: parsed.legitimacyCheck?.detectedOrganizations || [],
        sources: sources
      }
    };

    console.log('✅ Certificate verification completed:', finalAnalysis);

    return c.json(finalAnalysis);
    
  } catch (error) {
    console.error('❌ Certificate verification error:', error);
    
    return c.json({
      status: 'rejected',
      confidence: 0,
      fields: {
        name: null,
        issuer: null,
        issueDate: null,
        certNumber: null,
        detectedLinks: []
      },
      legitimacyCheck: {
        isLegitimate: false,
        reason: 'Ошибка при анализе сертификата. Попробуйте позже.',
        detectedOrganizations: [],
        sources: []
      }
    }, 500);
  }
});

// AI-powered competitions generation
app.post('/make-server-6738f032/ai/generate-competitions', async (c) => {
  try {
    const { country, city, direction, age, achievements } = await c.req.json();
    
    console.log('🏆 Generating AI competitions for:', { country, city, direction, age });

    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    if (!GEMINI_API_KEY || GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
      console.log('⚠️ GEMINI_API_KEY not configured, returning empty competitions');
      return c.json({
        success: true,
        competitions: {
          international: [],
          national: [],
          local: []
        }
      });
    }

    const prompt = `Ты - эксперт по международным и национальным образовательным соревнованиям и олимпиадам.

ЗАДАЧА: Сгенерируй персонализированный спсок соревнований для школьника/студента.

ДАННЫЕ ПОЛЬЗОВАТЕЛЯ:
- Страна: ${country}
- Город: ${city}
- Направление: ${direction}
- Возраст: ${age || 'не указан'}
- Достижения: ${achievements || 'не указаны'}

ТРЕБОВАНИЯ:
1. Верни JSON МАССИВ с тремя категориями соревнований
2. Для каждого соревнования укажи:
   - name: полное официальное название на русском
   - level: "international" / "national" / "local"
   - description: краткое описание (1-2 предложения на русском)
   - website: официальный сайт (реальная ссылка!)
   - relevance: оценка релевантности 0-100 (насколько подходит этому пользователю)

3. МЕЖДУНАРОДНЫЕ соревнования (5-7 штук):
   - Только реальные престижные международные соревнования
   - Релевантные направлению пользователя
   - IOI, IMO, IPhO, IChO, ISEF, Google Code Jam, Meta Hacker Cup, ICPC и т.д.

4. НАЦИОНАЛЬНЫЕ соревнования (5-7 штук):
   - Реальные республиканские/всероссийские/всеказахстанские олимпиады
   - Для России: ВсОШ (Всероссийская олимпиада школьников), Высшая проба, и т.д.
   - Для Казахстана: Республиканская олимпиада, РНПЦ "Дарын", и т.д.
   - Только соревнования страны пользователя!

5. ЛОКАЛЬНЫЕ соревнования (3-5 штук):
   - Городские/областные олимпиады
   - Соревнования от местных университетов
   - Хакатоны и конкурсы в регионе
   - Только для города/региона пользователя!

ВАЖНО:
- ВСЕ соревнования должны быть РЕАЛЬНЫМИ
- Даты и сайты должны быть корректными
- Релевантность рассчитывай исходя из направления и возраста
- Приоритет - соревнования, которые реально доступны для участия

ФОРМАТ ОТВЕТА (строго JSON):
{
  "international": [
    {
      "name": "International Olympiad in Informatics (IOI)",
      "level": "international",
      "description": "Престижная международная олимпиада по программированию для школьников до 20 лет",
      "website": "https://ioinformatics.org",
      "relevance": 95
    }
  ],
  "national": [...],
  "local": [...]
}

Отвечай ТОЛЬКО валидным JSON массивом, без комментариев.`;

    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                { text: prompt }
              ],
            },
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 4096,
          },
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('❌ Gemini API error:', geminiResponse.status, errorText);
      throw new Error(`Gemini API error: ${geminiResponse.status}`);
    }

    const geminiData = await geminiResponse.json();
    const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!responseText) {
      throw new Error('No response from Gemini API');
    }
    
    // Extract JSON from response
    let jsonText = responseText.trim();
    if (jsonText.includes('```json')) {
      jsonText = jsonText.split('```json')[1].split('```')[0].trim();
    } else if (jsonText.includes('```')) {
      jsonText = jsonText.split('```')[1].split('```')[0].trim();
    }
    
    const competitions = JSON.parse(jsonText);
    
    console.log('✅ Generated competitions:', {
      international: competitions.international?.length || 0,
      national: competitions.national?.length || 0,
      local: competitions.local?.length || 0,
    });

    return c.json({
      success: true,
      competitions
    });
  } catch (error: any) {
    console.error('❌ Error generating competitions:', error);
    return c.json(
      { error: 'Failed to generate competitions: ' + error.message },
      { status: 500 }
    );
  }
});

// ============= AI RECOMMENDATIONS STORAGE =============

// Get latest AI recommendations for user
app.get('/make-server-6738f032/ai/recommendations/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const supabase = getSupabaseClient();
    
    const { data: recommendations, error } = await supabase
      .from('ai_recommendations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error('Error getting AI recommendations:', error);
      return c.json({ error: 'Failed to get AI recommendations' }, 500);
    }
    
    return c.json(recommendations || null);
  } catch (error) {
    console.error('Error getting AI recommendations:', error);
    return c.json({ error: 'Failed to get AI recommendations' }, 500);
  }
});

// Save AI recommendations
app.post('/make-server-6738f032/ai/recommendations/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const data = await c.req.json();
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('ai_recommendations')
      .insert({
        user_id: userId,
        profile_snapshot: data.profileSnapshot || {},
        strengths: data.strengths || [],
        weaknesses: data.weaknesses || [],
        recommendations: data.recommendations || [],
        international_competitions: data.internationalCompetitions || [],
        national_competitions: data.nationalCompetitions || [],
        local_competitions: data.localCompetitions || [],
      });
    
    if (error) {
      console.error('Error saving AI recommendations:', error);
      return c.json({ error: 'Failed to save AI recommendations' }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error saving AI recommendations:', error);
    return c.json({ error: 'Failed to save AI recommendations' }, 500);
  }
});

// ============= AI MENTOR CONVERSATIONS STORAGE =============

// Get AI mentor conversation for user
app.get('/make-server-6738f032/ai/mentor/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // Create Supabase client with explicit credentials
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    if (!supabaseUrl || !serviceRoleKey) {
      console.error('❌ Missing Supabase credentials for GET!');
      return c.json({ 
        error: 'Server configuration error: Missing Supabase credentials'
      }, 500);
    }
    
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
        detectSessionInUrl: false
      }
    });
    
    const { data: conversation, error } = await supabase
      .from('ai_mentor_conversations')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error('❌ Error getting AI mentor conversation:', error);
      return c.json({ error: 'Failed to get AI mentor conversation', details: error }, 500);
    }
    
    return c.json(conversation || null);
  } catch (error) {
    console.error('❌ Error getting AI mentor conversation:', error);
    return c.json({ error: 'Failed to get AI mentor conversation', details: String(error) }, 500);
  }
});

// Save/Update AI mentor conversation
app.post('/make-server-6738f032/ai/mentor/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const data = await c.req.json();
    
    console.log('💾 Saving AI mentor query for user:', userId);
    console.log('📝 Data:', data);
    
    // Create Supabase client with explicit credentials
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    console.log('🔑 Credentials check:');
    console.log('   URL:', supabaseUrl ? `${supabaseUrl.substring(0, 30)}...` : 'MISSING');
    console.log('   Key:', serviceRoleKey ? `${serviceRoleKey.substring(0, 20)}...` : 'MISSING');
    
    if (!supabaseUrl || !serviceRoleKey) {
      console.error('❌ Missing Supabase credentials!');
      return c.json({ 
        error: 'Server configuration error: Missing Supabase credentials',
        details: {
          hasUrl: !!supabaseUrl,
          hasKey: !!serviceRoleKey
        }
      }, 500);
    }
    
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
        detectSessionInUrl: false
      }
    });
    
    console.log('✅ Supabase client created');
    
    // Check if conversation exists
    const { data: existing, error: selectError } = await supabase
      .from('ai_mentor_conversations')
      .select('id')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();
    
    if (selectError && selectError.code !== 'PGRST116') {
      console.error('❌ Error checking existing conversation:', selectError);
      return c.json({ 
        error: 'Failed to check existing conversation', 
        details: selectError 
      }, 500);
    }
    
    const saveData = {
      selected_regions: data.selected_regions || '[]',
      selected_difficulty: data.selected_difficulty || 'all',
      selected_category: data.selected_category || 'all',
      universities_shown: JSON.stringify(data.universities_shown || []),
      updated_at: new Date().toISOString(),
    };
    
    if (existing) {
      // Update existing
      console.log('📝 Updating existing query:', existing.id);
      const { error } = await supabase
        .from('ai_mentor_conversations')
        .update(saveData)
        .eq('id', existing.id);
      
      if (error) {
        console.error('❌ Error updating AI mentor conversation:', error);
        return c.json({ error: 'Failed to update AI mentor conversation', details: error }, 500);
      }
      console.log('✅ Query updated successfully');
    } else {
      // Insert new
      console.log('📝 Creating new query');
      const { error } = await supabase
        .from('ai_mentor_conversations')
        .insert({
          user_id: userId,
          ...saveData,
        });
      
      if (error) {
        console.error('❌ Error creating AI mentor conversation:', error);
        return c.json({ error: 'Failed to create AI mentor conversation', details: error }, 500);
      }
      console.log('✅ Query created successfully');
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error('❌ Error saving AI mentor conversation:', error);
    return c.json({ error: 'Failed to save AI mentor conversation', details: String(error) }, 500);
  }
});

// Clear AI mentor conversation
app.delete('/make-server-6738f032/ai/mentor/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('ai_mentor_conversations')
      .delete()
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error clearing AI mentor conversation:', error);
      return c.json({ error: 'Failed to clear AI mentor conversation' }, 500);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error clearing AI mentor conversation:', error);
    return c.json({ error: 'Failed to clear AI mentor conversation' }, 500);
  }
});

// ============= TEST ENDPOINT =============
app.get('/make-server-6738f032/test', (c) => {
  return c.json({ status: 'ok', message: 'Backend is running!', timestamp: new Date().toISOString() });
});

// ============= AI INSIGHTS =============
import { generateInsights, getInsights } from './ai-insights.tsx';

app.post('/make-server-6738f032/ai/insights/:userId/:bookId', generateInsights);
app.get('/make-server-6738f032/ai/insights/:userId/:bookId', getInsights);

// ============= MARKETPLACE =============

// Get all marketplace items
app.get('/make-server-6738f032/marketplace/items', async (c) => {
  try {
    const supabase = getSupabaseClient();
    
    // For now, return sample data. In production, fetch from database
    const sampleItems = [
      {
        id: 'course-1',
        title: 'Full Stack Web Development с React и Node.js',
        description: 'Научитесь создавать современные веб-приложения с нуля используя React, Node.js и MongoDB',
        price: 49.99,
        authorId: 'author-1',
        authorName: 'Александр Петров',
        type: 'course',
        category: 'technologyAndIT',
        thumbnailUrl: '',
        rating: 4.8,
        reviewCount: 245,
        salesCount: 1200,
        isPremium: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'book-1',
        title: 'Введение в Machine Learning',
        description: 'Полное руководство по машинному обучению с примерами на Python',
        price: 0,
        authorId: 'author-2',
        authorName: 'Мария Иванова',
        type: 'book',
        category: 'technologyAndIT',
        rating: 4.5,
        reviewCount: 89,
        salesCount: 450,
        isPremium: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'material-1',
        title: 'Шпаргалка по алгоритмам и структурам данных',
        description: 'Компактная шпаргалка с основными алгоритмами для подготовки к собеседованиям',
        price: 9.99,
        authorId: 'author-3',
        authorName: 'Дмитрий Сидоров',
        type: 'material',
        category: 'technologyAndIT',
        rating: 4.9,
        reviewCount: 567,
        salesCount: 3400,
        isPremium: false,
        createdAt: new Date().toISOString(),
      },
    ];

    return c.json({ items: sampleItems });
  } catch (error) {
    console.error('❌ Error fetching marketplace items:', error);
    return c.json({ error: 'Failed to fetch marketplace items' }, 500);
  }
});

// Get single marketplace item
app.get('/make-server-6738f032/marketplace/items/:itemId', async (c) => {
  try {
    const itemId = c.req.param('itemId');
    
    // Sample item with extended details
    const sampleItem = {
      id: itemId,
      title: 'Full Stack Web Development с React и Node.js',
      description: 'Научитесь создавать современные веб-приложения с нуля используя React, Node.js и MongoDB',
      price: 49.99,
      authorId: 'author-1',
      authorName: 'Александр Петров',
      type: 'course',
      category: 'technologyAndIT',
      rating: 4.8,
      reviewCount: 245,
      salesCount: 1200,
      isPremium: true,
      createdAt: new Date().toISOString(),
      whatYouLearn: [
        'Создание современных веб-приложений с React',
        'Backend разработка с Node.js и Express',
        'Работа с базами данных MongoDB',
        'RESTful API и аутентификация',
        'Деплой приложений на производство',
      ],
      requirements: [
        'Базовые знания HTML, CSS, JavaScript',
        'Понимание основ программирования',
        'Желание учиться и создавать проекты',
      ],
      content: 'Полный курс Full Stack разработки, который включает 50+ часов видео материалов, практические проекты и сертификат.',
    };

    return c.json({ item: sampleItem, isPurchased: false });
  } catch (error) {
    console.error('❌ Error fetching marketplace item:', error);
    return c.json({ error: 'Failed to fetch item' }, 500);
  }
});

// Purchase item
app.post('/make-server-6738f032/marketplace/purchase', async (c) => {
  try {
    const { itemId } = await c.req.json();
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // In production: process payment, save purchase record
    console.log('💳 Purchase request:', { itemId, token });

    return c.json({ 
      success: true, 
      message: 'Content purchased successfully',
      purchaseId: `purchase-${Date.now()}`,
    });
  } catch (error) {
    console.error('❌ Error processing purchase:', error);
    return c.json({ error: 'Purchase failed' }, 500);
  }
});

// Get creator content
app.get('/make-server-6738f032/marketplace/creator/content', async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Sample creator content
    const sampleContent = [
      {
        id: 'my-course-1',
        title: 'Мой первый курс',
        description: 'Обучающий курс по веб-разработке',
        price: 29.99,
        type: 'course',
        category: 'technologyAndIT',
        salesCount: 150,
        status: 'published',
        createdAt: new Date().toISOString(),
      },
    ];

    return c.json({ content: sampleContent });
  } catch (error) {
    console.error('❌ Error fetching creator content:', error);
    return c.json({ error: 'Failed to fetch content' }, 500);
  }
});

// Get creator stats
app.get('/make-server-6738f032/marketplace/creator/stats', async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Sample stats
    const stats = {
      totalSales: 150,
      monthlyEarnings: 1250.50,
      totalEarnings: 3600.00,
      totalContent: 1,
      commission: 0.20, // 20% platform commission
    };

    return c.json({ stats });
  } catch (error) {
    console.error('❌ Error fetching creator stats:', error);
    return c.json({ error: 'Failed to fetch stats' }, 500);
  }
});

// Create new content
app.post('/make-server-6738f032/marketplace/creator/content', async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // In production: process FormData, upload files to storage
    console.log('📝 Creating new content');

    return c.json({ 
      success: true,
      contentId: `content-${Date.now()}`,
    });
  } catch (error) {
    console.error('❌ Error creating content:', error);
    return c.json({ error: 'Failed to create content' }, 500);
  }
});

// Delete content
app.delete('/make-server-6738f032/marketplace/creator/content/:contentId', async (c) => {
  try {
    const token = c.req.header('Authorization')?.split(' ')[1];
    
    if (!token) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const contentId = c.req.param('contentId');
    console.log('🗑️ Deleting content:', contentId);

    return c.json({ success: true });
  } catch (error) {
    console.error('❌ Error deleting content:', error);
    return c.json({ error: 'Failed to delete content' }, 500);
  }
});

Deno.serve(app.fetch);