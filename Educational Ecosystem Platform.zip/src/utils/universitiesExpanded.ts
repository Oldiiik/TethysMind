import { UNIVERSITIES_DATABASE, UniversityData } from './universities';

// Generate additional universities to reach 1000 total
function generateUniversities(): UniversityData[] {
  const base = [...UNIVERSITIES_DATABASE];
  const regions: Array<'asia' | 'central-asia' | 'north-america' | 'europe' | 'south-america' | 'oceania'> = 
    ['asia', 'central-asia', 'north-america', 'europe', 'south-america', 'oceania'];
  
  const countries = {
    'asia': ['China', 'Japan', 'South Korea', 'India', 'Thailand', 'Malaysia', 'Indonesia', 'Vietnam', 'Philippines'],
    'central-asia': ['Kazakhstan', 'Uzbekistan', 'Kyrgyzstan', 'Tajikistan', 'Turkmenistan'],
    'north-america': ['USA', 'Canada', 'Mexico'],
    'europe': ['UK', 'Germany', 'France', 'Spain', 'Italy', 'Netherlands', 'Sweden', 'Poland', 'Portugal'],
    'south-america': ['Brazil', 'Argentina', 'Chile', 'Colombia', 'Peru'],
    'oceania': ['Australia', 'New Zealand'],
  };

  const allDirections = ['technology', 'science', 'engineering', 'business', 'medicine', 'law', 'humanities', 'arts'];
  
  const universityTypes = [
    'University', 'Institute of Technology', 'State University', 'National University', 
    'Technical University', 'Polytechnic University', 'College', 'Institute'
  ];

  const cities = [
    'Capital City', 'Metropolitan Area', 'Tech Hub', 'Academic Center', 'Innovation District',
    'University Town', 'Research Center', 'Education Hub', 'Science Park', 'Innovation Valley'
  ];

  const currentCount = base.length;
  const needed = 1000 - currentCount;

  for (let i = 0; i < needed; i++) {
    const currentRank = currentCount + i + 1;
    const region = regions[Math.floor(Math.random() * regions.length)];
    const country = countries[region][Math.floor(Math.random() * countries[region].length)];
    const uniType = universityTypes[Math.floor(Math.random() * universityTypes.length)];
    const city = cities[Math.floor(Math.random() * cities.length)];
    
    // Requirements scale with rank
    const gpaBase = currentRank < 100 ? 4.5 : 
                    currentRank < 300 ? 4.0 :
                    currentRank < 500 ? 3.5 :
                    currentRank < 700 ? 3.0 : 2.5;
    
    const ieltsBase = currentRank < 100 ? 7.0 :
                      currentRank < 300 ? 6.5 :
                      currentRank < 500 ? 6.0 :
                      currentRank < 700 ? 5.5 : 5.0;
    
    // SAT is primarily for North American universities
    const satBase = region === 'north-america' ? (
                      currentRank < 100 ? 1450 :
                      currentRank < 300 ? 1350 :
                      currentRank < 500 ? 1250 :
                      currentRank < 700 ? 1150 : 1100
                    ) : undefined;
    
    const achievementsBase = currentRank < 100 ? 2 :
                             currentRank < 300 ? 1 : 0;
    
    const acceptanceBase = currentRank < 100 ? 10 :
                           currentRank < 300 ? 35 :
                           currentRank < 500 ? 55 :
                           currentRank < 700 ? 70 : 85;
    
    // Select 2-4 random directions
    const numDirections = 2 + Math.floor(Math.random() * 3);
    const selectedDirections: string[] = [];
    const shuffled = [...allDirections].sort(() => Math.random() - 0.5);
    for (let j = 0; j < numDirections; j++) {
      selectedDirections.push(shuffled[j]);
    }

    const uniName = `${country} ${uniType} #${i + 1}`;
    const nameVariations = {
      ru: `${country === 'Kazakhstan' ? 'Казахстанский' : 
            country === 'USA' ? 'Американский' :
            country === 'UK' ? 'Британский' :
            country === 'China' ? 'Китайский' :
            country === 'Japan' ? 'Японский' :
            country === 'Germany' ? 'Немецкий' :
            'Международный'} ${uniType === 'University' ? 'университет' : 
                              uniType === 'Institute of Technology' ? 'технологический институт' :
                              uniType === 'College' ? 'колледж' : 'институт'} №${i + 1}`,
      kk: `${country === 'Kazakhstan' ? 'Қазақстандық' : 
            country === 'USA' ? 'Американдық' :
            country === 'UK' ? 'Британдық' :
            country === 'China' ? 'Қытайлық' :
            country === 'Japan' ? 'Жапондық' :
            country === 'Germany' ? 'Германдық' :
            'Халықаралық'} ${uniType === 'University' ? 'университет' : 
                            uniType === 'Institute of Technology' ? 'технологиялық институт' :
                            uniType === 'College' ? 'колледж' : 'институт'} №${i + 1}`,
    };

    const programs = selectedDirections.map(d => {
      if (d === 'technology') return ['Computer Science', 'IT', 'Software Engineering'];
      if (d === 'engineering') return ['Engineering', 'Mechanical Engineering', 'Civil Engineering'];
      if (d === 'business') return ['Business', 'Economics', 'Management'];
      if (d === 'medicine') return ['Medicine', 'Nursing', 'Public Health'];
      if (d === 'science') return ['Physics', 'Chemistry', 'Biology'];
      if (d === 'law') return ['Law', 'Legal Studies', 'Criminal Justice'];
      if (d === 'humanities') return ['History', 'Philosophy', 'Literature'];
      if (d === 'arts') return ['Arts', 'Design', 'Music'];
      return ['General Studies'];
    }).flat().slice(0, 4);

    const programsRu = programs.map(p => {
      const mapping: Record<string, string> = {
        'Computer Science': 'Компьютерные науки',
        'IT': 'ИТ',
        'Engineering': 'Инженерия',
        'Business': 'Бизнес',
        'Medicine': 'Медицина',
        'Law': 'Право',
        'Physics': 'Физика',
        'Chemistry': 'Химия',
        'Biology': 'Биология',
        'Arts': 'Искусство',
        'Design': 'Дизайн',
        'Economics': 'Экономика',
      };
      return mapping[p] || p;
    });

    const programsKk = programs.map(p => {
      const mapping: Record<string, string> = {
        'Computer Science': 'Компьютерлік ғылымдар',
        'IT': 'ИТ',
        'Engineering': 'Инженерия',
        'Business': 'Бизнес',
        'Medicine': 'Медицина',
        'Law': 'Құқық',
        'Physics': 'Физика',
        'Chemistry': 'Химия',
        'Biology': 'Биология',
        'Arts': 'Өнер',
        'Design': 'Дизайн',
        'Economics': 'Экономика',
      };
      return mapping[p] || p;
    });

    base.push({
      id: `gen-uni-${i + 1}`,
      name: uniName,
      nameRu: nameVariations.ru,
      nameKk: nameVariations.kk,
      location: `${city}, ${country}`,
      locationRu: `${city}, ${country}`,
      locationKk: `${city}, ${country}`,
      country,
      region,
      rank: currentRank,
      directions: selectedDirections,
      requirements: {
        minGPA: Math.round((gpaBase + (Math.random() * 0.3 - 0.15)) * 10) / 10,
        minIELTS: ieltsBase,
        minSAT: satBase,
        minAchievements: achievementsBase,
      },
      programs,
      programsRu,
      programsKk,
      tuitionFee: region === 'central-asia' ? `₸${Math.floor(Math.random() * 2000000 + 1000000)}` :
                  region === 'north-america' ? `$${Math.floor(Math.random() * 40000 + 15000)}` :
                  region === 'europe' ? `€${Math.floor(Math.random() * 15000 + 5000)}` :
                  region === 'oceania' ? `AUD $${Math.floor(Math.random() * 35000 + 20000)}` :
                  `$${Math.floor(Math.random() * 20000 + 5000)}`,
      acceptanceRate: Math.max(1, Math.min(99, Math.round(acceptanceBase + (Math.random() * 20 - 10)))),
    });
  }

  console.log(`✅ Generated ${base.length} universities for AI analysis`);
  return base;
}

// Export expanded database with 1000 universities
export const UNIVERSITIES_DATABASE_1000 = generateUniversities();